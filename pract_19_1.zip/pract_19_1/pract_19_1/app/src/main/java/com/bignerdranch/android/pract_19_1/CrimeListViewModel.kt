package com.bignerdranch.android.pract_19_1

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.util.UUID

class CrimeListViewModel:ViewModel() {

    private val crimeRepository:CrimeRepository = CrimeRepository.get()
    private val crimeIdLiveData = MutableLiveData<UUID>()

    fun saveCrime(crime: Crime)
    {
        crimeRepository.updateCrime(crime)
    }
}