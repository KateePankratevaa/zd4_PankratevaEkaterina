package com.bignerdranch.android.pract_19_1

import android.content.Context
import androidx.room.Room
import java.lang.IllegalStateException
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class CrimeRepository private constructor(context: Context) {
    private val database: CrimeDatabase = Room.databaseBuilder(
        context.applicationContext,
        CrimeDatabase::class.java,
        "crime.database"
    ).addMigrations(migration_1_2).build()

    private val crimeDao = database.crimeDao()

private val executor:Executor = Executors.newSingleThreadExecutor()

    fun updateCrime(crime:Crime)
    {
        executor.execute{
            crimeDao.updateCrimes(crime)
        }
    }

    fun addCrime(crime: Crime){
        executor.execute{
            crimeDao.addCrimes(crime)
        }
    }

    companion object{
        private var INSTANCE: CrimeRepository? = null
        fun get(): CrimeRepository{
            return INSTANCE?:throw IllegalStateException("CrimeRepository must be initializated")
        }
    }
}